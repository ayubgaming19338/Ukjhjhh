let points = 0;
let taskStatus = { "1": false, "2": false }; // Track task completion

// Show the appropriate tab
function showTab(tabId) {
  document.querySelectorAll(".content").forEach((content) => {
    content.classList.add("hidden");
  });
  document.getElementById(tabId).classList.remove("hidden");
}

function startGoblinMineTask() {

  const startButton = document.getElementById('start-btn-goblin');

  const claimButton = document.getElementById('claim-btn-goblin');

  const completedTick = document.getElementById('completed-tick-goblin');

  // Disable the start button and open the Telegram link

  startButton.setAttribute('disabled', true);

  window.open('https://t.me/GoblinMine_bot/start?startapp=5631192232', '_blank');

  

  // Show the "Completed" message after a delay (optional, you can adjust the time)

  setTimeout(function() {

    completedTick.classList.remove('hidden');  // Show completed message

    claimButton.classList.remove('hidden');  // Show the claim button

  }, 3000);  // Adjust the delay as needed (3 seconds)

}

function claimTask(task) {

  // Handle the claim logic here

  alert('You have successfully claimed your reward for completing ' + task + ' task!');

  // You can also add the logic to update points or make a server request here

}

function handleTask(button, link) {
  button.setAttribute('disabled', true);  // Disable the start button
  window.open(link, '_blank');  // Open the link in a new tab
  setTimeout(function() {
    button.nextElementSibling.classList.remove('hidden');  // Show the "Completed" message
  }, 2000);  // Delay before showing the completed message (for example, 2 seconds)
}

function startTelegramTask(button) {

  if (button.textContent === "Start") {

    // Open the Telegram link

    window.open("https://t.me/RabbitAnnounce", "_blank");

    // Update button to "Claim"

    button.textContent = "Claim";

    button.style.backgroundColor = "#ffc107"; // Change to progress color

  } else if (button.textContent === "Claim") {

    // Mark task as completed

    button.textContent = "Completed";

    button.style.backgroundColor = "#28a745"; // Change to completed color

    const completedMessage = button.nextElementSibling;

    completedMessage.classList.remove("hidden");

  }

}

// Start YouTube task
function startYoutubeTask(taskId) {
  if (!taskStatus[taskId]) {
    const links = {
      "1": "https://youtube.com/@balnat1?si=KUs4ayMCoND2r6NK",
      "2": "https://youtube.com/@craze_112?si=eA2twAPLqULk960K",
    };
    window.open(links[taskId], "_blank");
    document.getElementById(`claim-btn-${taskId}`).classList.remove("hidden");
    alert("Subscribe to the channel and then claim your reward!");
  } else {
    alert("This task is already completed!");
  }
}

// Claim reward for YouTube task
function claimYoutubeReward(taskId) {
  if (!taskStatus[taskId]) {
    alert(`You earned 100 points for completing Task ${taskId}!`);
    points += 100;
    updatePoints();

    // Mark task as completed
    taskStatus[taskId] = true;
    document.getElementById(`claim-btn-${taskId}`).classList.add("hidden");
    document.getElementById(`start-btn-${taskId}`).classList.add("hidden");
    document.getElementById(`completed-tick-${taskId}`).classList.remove("hidden");
  } else {
    alert("You have already claimed this reward!");
  }
}

// Update points display
function updatePoints() {
  document.getElementById("points").textContent = `${points} 💸`;
}

// Refer a friend
function referFriend() {
  alert("You earned 300 points for referring a friend!");
  points += 300;
  updatePoints();
}

// Withdraw points
function withdraw() {
  if (points >= 500) {
    points -= 500;
    document.getElementById("withdraw-msg").textContent = "Withdrawal request submitted successfully!";
    updatePoints();
  } else {
    document.getElementById("withdraw-msg").textContent = "You need at least 500 points to withdraw!";
  }
}